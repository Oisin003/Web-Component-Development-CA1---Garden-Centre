// Oisin Gibson
// L00172671

// src/components/Login.jsx
// User authentication component with phone number and name validation
// Provides login form with real-time phone number validation using libphonenumber-js

/* 
 * REFERENCES & DOCUMENTATION:
 * 
 * React Hooks & State Management:
 * - useState Hook: https://react.dev/reference/react/useState
 * - React Forms: https://react.dev/learn/reacting-to-input-with-state
 * - Event Handling: https://react.dev/learn/responding-to-events
 * 
 * React Router Navigation:
 * - useNavigate Hook: https://reactrouter.com/en/main/hooks/use-navigate
 * - React Router v6 Guide: https://reactrouter.com/en/main/getting-started/tutorial
 * 
 * Phone Number Validation:
 * - libphonenumber-js: https://www.npmjs.com/package/libphonenumber-js
 * - Phone validation examples: https://github.com/catamphetamine/libphonenumber-js#usage
 * 
 * Bootstrap Icons:
 * - Bootstrap Icons Library: https://icons.getbootstrap.com/
 * - SVG Implementation: https://developer.mozilla.org/en-US/docs/Web/SVG/Tutorial
 * 
 * Authentication Patterns:
 * - React Authentication Tutorial: https://kentcdodds.com/blog/authentication-in-react-applications
 * - Context API for Auth: https://react.dev/learn/passing-data-deeply-with-context
 */

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { isValidPhoneNumber } from 'libphonenumber-js';
// import './Login.css';
import '../Login.css'

const Login = () => {// Arrow function to define Login component
    // Local state for form fields and validation
    const [name, setName] = useState('');           // User's full name
    const [phoneNumber, setPhoneNumber] = useState(''); // User's phone number
    const [password, setPassword] = useState('');   // User's password
    const [error, setError] = useState('');         // Error message display
    const [isPhoneValid, setIsPhoneValid] = useState(null); // Phone validation status (null/true/false)

    // React Router hook for navigation after successful login
    const navigate = useNavigate();
    // Authentication context hook for login functionality
    const { login } = useAuth();

    // Handle phone number input changes with real-time validation
    const handlePhoneChange = (e) => {// Arrow function to handle phone number input changes
        const value = e.target.value;
        setPhoneNumber(value);

        // Validate phone number using libphonenumber-js (using Ireland as default country)
        if (value.trim()) {
            // Check if phone number is valid for Irish format
            const valid = isValidPhoneNumber(value, 'IE');
            setIsPhoneValid(valid);
        } else {
            // Reset validation state when field is empty
            setIsPhoneValid(null);
        }
    };

    // Handle form submission with validation
    const handleSubmit = (e) => {// Arrow function to handle form submission
        e.preventDefault(); // Prevent default form submission behavior

        // Check if phone number is valid before attempting login
        if (!isPhoneValid) {
            setError('Please enter a valid phone number');
            return;
        }

        try {
            // Attempt login with provided credentials
            login(name, phoneNumber, password);
            // Navigate to home page on successful login
            navigate('/');// This is a hook - Use navigate to redirect user - React Router function call
        } catch (err) {
            // Display error message if login fails
            setError('Failed to log in');
        }
    };

    return (
        <div className="login-page">
            {/* Login Card - Main container for the login form */}
            <div className="login-card">
                {/* Card Header - Welcome message and description */}
                <div className="card-header">
                    <h2>Welcome Back</h2>
                    <p>Please login to continue</p>
                </div>

                {/* Card Body - Contains the login form */}
                <div className="card-body">
                    <form onSubmit={handleSubmit} className="login-form">
                        {/* Error Message Display - Shows validation or login errors */}
                        {error && <div className="error-message">{error}</div>}

                        {/* Name Input Field */}
                        <div className="form-group">
                            <label>Name
                                {/* Person icon using Bootstrap Icons SVG */}
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person" viewBox="0 0 16 16">
                                    <path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6m2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0m4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4m-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10s-3.516.68-4.168 1.332c-.678.678-.83 1.418-.832 1.664z" />
                                </svg>
                            </label>
                            <input
                                type="text"
                                value={name}
                                onChange={(e) => setName(e.target.value)} // Update name state on input change
                                required
                                placeholder="Enter your full name"
                            />
                        </div>

                        {/* Phone Number Input Field with Real-time Validation */}
                        <div className="form-group">
                            <label>Phone Number
                                {/* Telephone icon using Bootstrap Icons SVG */}
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-telephone" viewBox="0 0 16 16">
                                    <path d="M3.654 1.328a.678.678 0 0 0-1.015-.063L1.605 2.3c-.483.484-.661 1.169-.45 1.77a17.568 17.568 0 0 0 4.168 6.608 17.569 17.569 0 0 0 6.608 4.168c.601.211 1.286.033 1.77-.45l1.034-1.034a.678.678 0 0 0-.063-1.015l-2.307-1.794a.678.678 0 0 0-.58-.122L9.98 10.72a.678.678 0 0 1-.67-.15L6.22 7.48a.678.678 0 0 1-.15-.67l.293-1.806a.678.678 0 0 0-.122-.58L4.447 2.117a.678.678 0 0 0-.793-.064z" />
                                </svg>
                            </label>
                            <input
                                type="tel"
                                value={phoneNumber}
                                onChange={handlePhoneChange} // Custom handler for phone validation
                                required
                                placeholder="Enter your phone number (e.g., +353 87 123 4567)"
                                style={{
                                    // Dynamic border color based on validation state
                                    borderColor: isPhoneValid === false ? '#ff4444' : isPhoneValid === true ? '#44ff44' : '',
                                }}
                            />
                            {/* Invalid phone number feedback */}
                            {isPhoneValid === false && (
                                <small style={{ color: 'orange', fontSize: '12px' }}>
                                    Please enter a valid phone number
                                </small>
                            )}
                            {/* Valid phone number feedback */}
                            {isPhoneValid === true && (
                                <small style={{ color: 'green', fontSize: '12px' }}>
                                    Valid phone number
                                </small>
                            )}
                        </div>

                        {/* Password Input Field */}
                        <div className="form-group">
                            <label>Password
                                {/* Lock icon using Bootstrap Icons SVG */}
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-lock" viewBox="0 0 16 16">
                                    <path fill-rule="evenodd" d="M8 0a4 4 0 0 1 4 4v2.05a2.5 2.5 0 0 1 2 2.45v5a2.5 2.5 0 0 1-2.5 2.5h-7A2.5 2.5 0 0 1 2 13.5v-5a2.5 2.5 0 0 1 2-2.45V4a4 4 0 0 1 4-4M4.5 7A1.5 1.5 0 0 0 3 8.5v5A1.5 1.5 0 0 0 4.5 15h7a1.5 1.5 0 0 0 1.5-1.5v-5A1.5 1.5 0 0 0 11.5 7zM8 1a3 3 0 0 0-3 3v2h6V4a3 3 0 0 0-3-3" />
                                </svg>
                            </label>
                            <input
                                type="password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)} // Update password state on input change
                                required
                                placeholder="Enter your password"
                            />
                        </div>

                        {/* Submit Button with Conditional Disabled State */}
                        <button
                            type="submit"
                            className="login-button"
                            // Button is disabled if phone is invalid or any required field is empty
                            disabled={isPhoneValid === false || !name || !phoneNumber || !password}
                        >
                            Login
                        </button>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default Login;
