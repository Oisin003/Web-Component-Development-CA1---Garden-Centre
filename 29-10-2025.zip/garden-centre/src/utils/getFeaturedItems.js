// src/utils/getFeaturedItems.js

/* 
 * REFERENCES & DOCUMENTATION:
 * 
 * JavaScript Array Methods:
 * - Array.isArray(): https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/isArray
 * - Array.filter(): https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/filter
 * - Array.slice(): https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/slice
 * - Object.values(): https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/values
 * - Spread Operator: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Spread_syntax
 * 
 * Algorithm Design:
 * - Array Normalization Patterns: https://javascript.info/array-methods
 * - Data Filtering Strategies: https://www.freecodecamp.org/news/javascript-array-filter-tutorial/
 * - Default Parameters: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Functions/Default_parameters
 */

// Utility function to extract featured items from product collections
// Supports both array and object (categorized) product structures
export function getFeaturedItems(productsInput, count = 4) {
  // Guard clause: return empty array if no products provided
  if (!productsInput) return [];

  // Normalize to a flat array whether caller passed an object (categories) or an array
  // This pattern allows flexibility in data structure handling
  const all =
    Array.isArray(productsInput) ? productsInput : Object.values(productsInput).flat();

  // Additional validation for empty or invalid data
  if (!all || all.length === 0) return [];

  // Strategy 1: Prefer explicit featured flag for curated content
  // Filter products that have been manually marked as featured
  const featured = all.filter((p) => p && p.featured);
  if (featured.length >= count) return featured.slice(0, count);

  // Strategy 2: Fill up with non-featured items to reach desired count
  // Ensures we always return the requested number of items when possible
  const selected = [...featured]; // Start with featured items using spread operator
  
  // Iterate through all products to fill remaining slots
  for (const p of all) {
    if (selected.length >= count) break; // Stop when we have enough items
    if (!selected.includes(p)) selected.push(p); // Avoid duplicates
  }

  // Return exactly the requested count (or fewer if not enough products)
  return selected.slice(0, count);
}
