// Oisin Gibson
// L00172671
// src/App.jsx

// Components handle page navigation in a React Single Page Application
// A React SPA uses client-side routing to navigate between different views without reloading the page
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from './context/AuthContext';
import Header from "./components/Header";
import Footer from "./components/Footer";
import Home from "./pages/Home";
import ProductsPage from "./pages/ProductsPage";
import BasketPage from "./pages/BasketPage";
import CheckoutPage from "./pages/CheckOutPage";
import { BasketProvider } from "./context/BasketContext";
import Login from './components/Login';
import "./App.css";

// Arrow funtction for ProtectedRoute component 
const ProtectedRoute = ({ children }) => {// Accepts children components as props
  const { user } = useAuth();// Access current user from authentication
  if (!user) return <Navigate to="/login" />;// If the user is not logged in rediect to Login Page
  return children;// 
};

// The Protected Route makes sure the user is logged in so before the access the other pages
// https://www.geeksforgeeks.org/reactjs/how-to-create-a-protected-route-with-react-router-dom/

function AppContent() {
  const { user } = useAuth();// Access current user from authentication
  return (
    <div className="App">
      <Header />
      <main className="main-content">
        <Routes>
          {/* Element specifys what componenet should be rendered */}
          <Route path="/login" element={<Login />} />/
          <Route path="/" element={
            <ProtectedRoute>
              <Home />
            </ProtectedRoute>
          } />
          <Route path="/plants" element={
            <ProtectedRoute>
              <ProductsPage category="Plants" />
            </ProtectedRoute>
          } />
          <Route path="/tools" element={
            <ProtectedRoute>
              <ProductsPage category="Tools" />
            </ProtectedRoute>
          } />
          <Route path="/garden-care" element={
            <ProtectedRoute>
              <ProductsPage category="Garden Care" />
            </ProtectedRoute>
          } />
          <Route path="/basket" element={
            <ProtectedRoute>
              <BasketPage />
            </ProtectedRoute>
          } />
          <Route path="/checkout" element={
            <ProtectedRoute>
              <CheckoutPage />
            </ProtectedRoute>
          } />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}
//http://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Frameworks_libraries/React_components
// Use the AppContent to separate the routing logic from the context providers
// This keeps the App component clean and focused on providing context and routing
// Also makes sure the user is logged in before accessing any page
function App() {// 
  return (
    <BrowserRouter> 
      <AuthProvider>
        <BasketProvider>
          <AppContent />
        </BasketProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}

export default App;
