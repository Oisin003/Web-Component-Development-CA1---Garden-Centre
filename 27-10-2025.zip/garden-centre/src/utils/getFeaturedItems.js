// src/javascript/getFeaturedItems.js

export function getFeaturedItems(products) {
  const dayIndex = new Date().getDate(); // Get current day of the month
  const allItems = Object.values(products).flat(); // Flatten all categories into one array

  // Rotate items daily using modulo
  const startIndex = dayIndex % allItems.length;
  const selected = [];

  for (let i = 0; i < 2; i++) {
    const item = allItems[(startIndex + i) % allItems.length];
    const imageIndex = dayIndex % item.images.length;
    selected.push({
      ...item,
      image: item.images[imageIndex]
    });
  }

  return selected;
}
