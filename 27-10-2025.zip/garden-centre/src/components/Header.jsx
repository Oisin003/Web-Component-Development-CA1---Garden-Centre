// Oisin Gibson
// L00172671
// src/components/Header.jsx
import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import logo from '../images/logo/logo.jpg';
import '../App.css';


const Header = () => {
    const { user, logout } = useAuth();

    return (
        <header>
            {/* Top Banner */}
            <div className="top-banner">
                Call us: 074-9121541 / 074-9121545 | NI: 00 353 74 9121541 | Orders by phone only
            </div>
            
            {/* Header Container */}
            <div className="header-container">
                <div className="header-content">
                    {/* Logo Section */}
                    <div className="logo-section">
                        <img src={logo} alt="Tropical World Garden Centre Logo" />
                        <div className="logo-text">
                            <h1>Tropical World Garden Centre</h1>
                            <p>Your one-stop shop for all things gardening!</p>
                        </div>
                    </div>
                </div>
            </div>

            {/* Navigation */}
            <nav className="nav-container">
                <div className="main-nav">
                    <Link to="/"><i className="fas fa-home"></i> Home</Link>
                    <Link to="/plants"><i className="fas fa-seedling"></i> Plants</Link>
                    <Link to="/garden-care"><i className="fas fa-leaf"></i> Garden Care</Link>
                    <Link to="/tools"><i className="fas fa-tools"></i> Tools</Link>
                    <Link to="/basket"><i className="fas fa-shopping-basket"></i> Basket</Link>
                    {user && (
                        <Link to="/" onClick={logout} className="logout-link">
                            <i className="fas fa-sign-out-alt"></i> Logout
                        </Link>
                    )}
                </div>
            </nav>
        </header>
    );
};

export default Header;


