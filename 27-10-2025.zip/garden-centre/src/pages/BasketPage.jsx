// src/pages/BasketPage.jsx
import { useBasket } from "../context/BasketContext";
import { Link } from "react-router-dom";
import "../ProductCard.css"

const BasketPage = () => {
    const { basketItems, removeFromBasket } = useBasket();

    const handleRemoveItem = (item) => {
        removeFromBasket(item);
    };

    let total = basketItems.reduce((sum, item) => sum + item.price, 0);

    return (
        <section className="basket-page">
            <h2>Shopping Basket</h2>

            {basketItems.length === 0 ? (
                <p>Your basket is empty.</p>
            ) : (
                <>
                    <div className="basket-items">
                        {basketItems.map((item, index) => (
                            <div key={index} className="basket-item">
                                <img 
                                    src={item.images[0]} 
                                    alt={item.name}
                                />
                                <div className="item-details">
                                    <h3>{item.name}</h3>
                                    <p>€{item.price.toFixed(2)}</p>
                                    <button 
                                        onClick={() => handleRemoveItem(item)}
                                        className="remove-button"
                                    >
                                        Remove from Basket
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>
                    <h3 className="total">
                        Total: €{total.toFixed(2)}
                    </h3>
                    <Link to="/checkout" className="nav-btn">
                        Proceed to Checkout
                    </Link>
                </>
            )}
        </section>
    );
};

export default BasketPage;
