// Import core React functionality
import React from 'react';
// Import the new React 18 root API from react-dom/client
import ReactDOM from 'react-dom/client';
// Import global styles
import './index.css';
// Import the main App component
import App from './App';
// Import performance measuring tool 
import reportWebVitals from './reportWebVitals';
// Create the root of your React app using the new React 18 API
const root = ReactDOM.createRoot(document.getElementById('root'));
// Render your app inside React.StrictMode (helps catch potential issues)
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
// Optional: start measuring performance (can log or send to analytics)
reportWebVitals();
