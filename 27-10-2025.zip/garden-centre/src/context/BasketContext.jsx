// Oisin Gibson
// L00172671
// src/context/BasketContext.jsx
import React, { createContext, useContext, useState } from "react";

export const BasketContext = createContext(); // Add export here

export function BasketProvider({ children }) {
  // useState hook stores all items currently in the basket
  // Create Variable, Function to Update state, initial empty array[]
  let [basketItems, setBasketItems] = useState([]);

  // Function to add an item to the basket
  let addToBasket = (item) => {
    //Arrow function to add an item to the basket
    setBasketItems((prevItems) => [...prevItems, item]);
  };

  // Updated removeFromBasket function to remove specific item
  let removeFromBasket = (itemToRemove) => {
    setBasketItems((prevBasket) => {
      // Find the index of the first occurrence of the item
      const indexToRemove = prevBasket.findIndex(
        (item) => item.id === itemToRemove.id
      );

      if (indexToRemove === -1) return prevBasket;

      // Create new array without the specific item
      return [
        ...prevBasket.slice(0, indexToRemove),
        ...prevBasket.slice(indexToRemove + 1),
      ];
    });
  };

  // Function to clear basket after checkout
  let clearBasket = () => {
    //Arrow function to clear the basket
    setBasketItems([]);
  };

  // Provide both data and functions to all children components
  return (
    // https://react.dev/reference/react/useContext
    // This component shares basket-related data and functions with all its child components (React Context API)
    <BasketContext.Provider
      value={{
        basketItems, // The current contents of the basket
        addToBasket, // Function to add a product to the basket
        removeFromBasket, // Function to remove a product from the basket
        clearBasket, // Function to empty the basket completely
      }}
    >
      {/* Render all child components that are wrapped inside BasketProvider */}
      {children}
    </BasketContext.Provider>
  );
}

export const useBasket = () => useContext(BasketContext);
