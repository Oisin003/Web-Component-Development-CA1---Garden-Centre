// Oisin Gibson
// L00172671
// src/components/Header.jsx

/* 
 * REFERENCES & DOCUMENTATION:
 * 
 * React Router Navigation:
 * - Link Component: https://reactrouter.com/en/main/components/link
 * - React Router Guide: https://reactrouter.com/en/main/getting-started/tutorial
 * 
 * Header Design Patterns:
 * - Responsive Navigation: https://css-tricks.com/responsive-navigation-patterns/
 */

import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { SearchContext } from '../context/SearchContext';
import logo from '../images/logo/logo.jpg';
import '../App.css';


const Header = () => {// Arrow notation to define Header 
    const { user, logout } = useAuth();
    const { query, setQuery } = useContext(SearchContext);

    return (
        <header className="header">
            {/* Top Banner */}
            <div className="top-banner">
                <div className="banner-content">
                    <div className="contact-info">
                        <i className="fas fa-phone"></i>
                        <span>Call us: 074-9121541 / 074-9121545</span>
                    </div>
                    <div className="contact-info">
                        <i className="fas fa-map-marker-alt"></i>
                        <span>NI: 00 353 74 9121541</span>
                    </div>
                    <div className="contact-info">
                        <i className="fas fa-shipping-fast"></i>
                        <span>Orders by phone only</span>
                    </div>
                </div>
            </div>
            
            {/* Header Container */}
            <div className="header-container">
                <div className="header-content">
                    {/* Logo Section */}
                    <div className="logo-section">
                        <div className="logo-wrapper">
                            <img src={logo} alt="Tropical World Garden Centre Logo" />
                            <div className="logo-glow"></div>
                        </div>
                        <div className="logo-text">
                            <h1>
                                <span className="tropical">Tropical</span>
                                <span className="world">World</span>
                                <span className="garden">Garden Centre</span>
                            </h1>
                            <p className="tagline">
                                <i className="fas fa-leaf"></i>
                                Your one-stop shop for all things gardening!
                                <i className="fas fa-seedling"></i>
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            {/* Navigation */}
            <nav className="nav-container">
                <div className="main-nav">
                    <Link to="/" className="nav-link">
                        <i className="fas fa-home"></i> 
                        <span>Home</span>
                    </Link>
                    <Link to="/plants" className="nav-link">
                        <i className="fas fa-seedling"></i> 
                        <span>Plants</span>
                    </Link>
                    <Link to="/garden-care" className="nav-link">
                        <i className="fas fa-leaf"></i> 
                        <span>Garden Care</span>
                    </Link>
                    <Link to="/tools" className="nav-link">
                        <i className="fas fa-tools"></i> 
                        <span>Tools</span>
                    </Link>
                    <Link to="/basket" className="nav-link basket-link">
                        <i className="fas fa-shopping-basket"></i> 
                        <span>Basket</span>
                        <div className="basket-indicator"></div>
                    </Link>
                    {user && (
                        <Link to="/" onClick={logout} className="nav-link logout-link">
                            <i className="fas fa-sign-out-alt"></i> 
                            <span>Logout</span>
                        </Link>
                    )}
                </div>
            </nav>
        </header>
    );
};

export default Header;


