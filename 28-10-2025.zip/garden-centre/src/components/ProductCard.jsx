// Oisin Gibson
// L00172671
// src/components/ProductCard.jsx

// Import React hooks
import React, { useContext, useState } from "react";

// Import the basket context to access shared basket functions and data
import { useBasket } from "../context/BasketContext";

// Import styles specific to the product card
import "../ProductCard.css";

// Define the ProductCard component + receive product details as props
export default function ProductCard({ item, id, name, price, images, placeholderMessage }) {
  // Normalize product data: prefer item object, fall back to individual props
  const product = item || (id ? { id, name, price, images } : null);

  // Access basket-related functions and data from context
  const { addToBasket, removeFromBasket, basketItems } = useBasket();

  // initialize "added" from basket state if product exists
  const [added, setAdded] = useState(() =>
    Boolean(product && basketItems?.some((b) => b.id === product.id))
  );

  // If there's no product data, render a placeholder card
  if (!product) {
    return (
      <div className="product-card placeholder">
        <div className="product-image placeholder-image" />
        <div className="product-info">
          <h3>{placeholderMessage || "Item not found"}</h3>
        </div>
      </div>
    );
  }

  const imgSrc = product.images?.[0] || product.image || "";

  const handleAdd = () => {
    if (added) {
      // remove the whole product object from basket (BasketPage expects item)
      removeFromBasket(product);
      setAdded(false);
      return;
    }

    // ensure images is always an array
    const normalized = {
      id: product.id,
      name: product.name,
      price: product.price ?? 0,
      images: Array.isArray(product.images)
        ? product.images
        : product.image
        ? [product.image]
        : [],
    };

    addToBasket(normalized);
    setAdded(true);
  };

  // Render the product card UI
  return (
    <div className="product-card">
      {imgSrc ? (
        <img
          src={imgSrc}
          alt={product.name}
          onError={(e) => {
            console.warn("Image failed to load:", imgSrc);
            e.currentTarget.onerror = null;
            e.currentTarget.src = "/images/placeholder.png";
          }}
        />
      ) : (
        <div className="product-image placeholder-image" />
      )}

      <div className="content">
        <h3>{product.name}</h3>
        <div className="meta">
          <p>€{(product.price ?? 0).toFixed(2)}</p>
        </div>
        <button className="cardButton" onClick={handleAdd}>
          {added ? "Remove from Basket" : "Add to Basket"}
        </button>
      </div>
    </div>
  );
}
