// Oisin Gibson
// L00172671

// src/pages/Home.jsx
import React, { useState, useEffect, useContext } from "react";
import '../Home.css';
import { products } from "../data/stock";
import { getFeaturedItems } from "../utils/getFeaturedItems";
import { SearchContext } from "../context/SearchContext"; // added
import ProductCard from "../components/ProductCard"; // added

function Home() {
  const { query, setQuery } = useContext(SearchContext); // added

  // UseHook - Declare state showEmailCard - set it to false to hide it - setShowEmailCard updates it
  let [showEmailCard, setShowEmailCard] = useState(false);
  //UseSate Hook - creates local component state for featured items - empty array
  let [featuredItems, setFeaturedItems] = useState([]);

  //useEffect Hook - runs once when component mounts - selects featured items from stock data
  useEffect(() => {
    // Calls function - passes it into projects 
    const selected = getFeaturedItems(products);
    //updates local sate with the selected products
    setFeaturedItems(selected);
  }, []);// dependency array is empty - runs only once on mount

  // prepare search results (null when no query)
  const q = (query || "").trim().toLowerCase();
  const allProducts = Object.values(products).flat();
  const searchResults = q ? allProducts.filter(p => p.name.toLowerCase().includes(q)) : null;

  return (
    <main>
      {/* Welcome Message */}
      <h2 className="welcome">Welcome to the Garden Centre</h2>

      {/* Central Search Bar — now wired to SearchContext */}
      <input
        type="text"
        placeholder="Search plants, tools, care..."
        className="search-bar"
        value={query || ""}
        onChange={(e) => setQuery(e.target.value)}
      />

      {/* Featured Products OR Search Results */}
      <div className="featured-products">
        {q ? (
          <>
            <h3>Search results for "{query}"</h3>
            <div className="product-cards">
              {searchResults.length > 0 ? (
                searchResults.map(item => (
                  <ProductCard key={item.id} item={item} />
                ))
              ) : (
                <ProductCard placeholderMessage={`Sorry, "${query}" is out of stock`} />
              )}
            </div>
          </>
        ) : (
          <>
            {/* Section heading */}
            <h3>Featured This Season</h3>
            {/* Grid container for product cards */}
            <div className="product-cards">
              {/* Loop through the featuredItems array and render each product */}
              {featuredItems.map(item => (
                // Individual product card with a unique key for React's reconciliation
                <div className="card" key={item.id}>
                  {/* Display the product image */}
                  <img src={item.image} alt={item.name} />
                  {/* Display the product name and price - two decimal points */}
                  <p>{item.name} – €{item.price.toFixed(2)}</p>
                </div>
              ))}
            </div>
          </>
        )}
      </div>

      {/* Newsletter Prompt */}
      <div className="newsletter-prompt">
        <p>Stay updated with seasonal tips and offers!</p>
        <button
          className="sub_button"
          // Arrow notation used to define the onClick event handler function - True means show
          onClick={() => setShowEmailCard(true)}
        >
          Subscribe
        </button>
      </div>

      {/* Email Card: Conditionally rendered when showEmailCard is true */}
      {showEmailCard && ( // Checks if the Card is true or false - if true show the card
        <div className="email-card">
          {/* Card Header */}
          <h5>Subscribe to our newsletter</h5>
          <p>Enter your email to receive updates:</p>

          {/* Email Form */}
          <form className="email-form">
            {/* Email Input Field */}
            <input
              type="email"
              placeholder="Email address"
              className="form-control"
            />

            {/* Submit Button*/}
            <button type="submit" className="sub_button">
              Submit
            </button>

            {/* Cancel Button: closes the email subscription card */}
            <button
              type="button"
              className="sub_button" // Bootstrap styling: grey button with top margin
              onClick={() => setShowEmailCard(false)} // React event handler: hides the email card by updating state - arrow notation used
            >
              Cancel
            </button>

          </form>
        </div>
      )}

      {/* About Section */}
      <div className="about-section">
        <h3>About Us</h3>
        <p>
          We’re passionate about helping you grow your dream garden. From native plants to eco-friendly tools, we’ve got everything you need to thrive.
        </p>
      </div>
    </main>
  );
}

export default Home;
