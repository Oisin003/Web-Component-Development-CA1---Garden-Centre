// src/pages/BasketPage.jsx
import { useBasket } from "../context/BasketContext";
import { Link } from "react-router-dom";
import "../ProductCard.css"

const BasketPage = () => {// Arrow fuction to define the BasketPage component
    // Destructure basketItems and removeFromBasket from useBasket context
    const { basketItems, removeFromBasket } = useBasket();// Hook to access basket context
    // Function to handle item removal from basket
    const handleRemoveItem = (item) => {
        removeFromBasket(item);
    };

    // .reduce() takes the array of basketItems and sums up their prices (0 is the inital value)
    let total = basketItems.reduce((sum, item) => sum + item.price, 0);

    return (
        <section className="basket-page">
            <h2>Shopping Basket</h2>

            {basketItems.length === 0 ? (
                <p>Your basket is empty.</p>
            ) : (
                <>
                    <div className="basket-items">
                        {basketItems.map((item, index) => (
                            <div key={index} className="basket-item">
                                <img
                                    src={item.images?.[0] || item.image || "/images/placeholder.png"}
                                    alt={item.name || "Product"}
                                    className="basket-image"
                                    onError={(e) => {
                                        console.warn("Basket image failed:", e.currentTarget.src);
                                        e.currentTarget.onerror = null;
                                        e.currentTarget.src = "/images/placeholder.png";
                                    }}
                                />
                                <div className="item-details">
                                    <h3>{item.name}</h3>
                                    {/* Display the price to 2 decimal places */}
                                    <p>€{item.price.toFixed(2)}</p>
                                    {/* Use the handleRemoveItem function to remove item */}
                                    <button
                                        onClick={() => handleRemoveItem(item)}
                                        className="remove-button"
                                    >
                                        Remove from Basket
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>
                    {/* Display the total price to 2 decimal places */}
                    <h3 className="total">
                        Total: €{total.toFixed(2)}
                    </h3>
                    <Link to="/checkout" className="nav-btn">
                        Proceed to Checkout
                    </Link>
                </>
            )}
        </section>
    );
};

export default BasketPage;
