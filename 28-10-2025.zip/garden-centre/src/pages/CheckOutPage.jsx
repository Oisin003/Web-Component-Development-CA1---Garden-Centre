// src/pages/CheckoutPage.jsx
import { useContext, useState } from "react";
import { useBasket } from "../context/BasketContext"; // Change this line
import { useAuth } from '../context/AuthContext';
import "../CheckOutPage.css";
// import {handlePhoneChange} from "../utils/checkPhoneNumber";
// import { isValidPhoneNumber } from 'libphonenumber-js';

const CheckOutPage = () => {
  const { basketItems, clearBasket } = useBasket(); // Add clearBasket here
  const { user } = useAuth();
  //Phine Validation

  // const [isValid, setIsValid] = useState(null);

  // Form state for user details
  let [form, setForm] = useState({ // useState hook to manage form data
    name: "",
    email: "",
    phone: "",
    address: "",
  }); 

  // Handle input changes
  let handleChange = (e) => { // Arrow function to handle input changes
    // Copy the existing form using pread operator then sets the key to the inputs name and sets the new value based on user input   
    setForm({ ...form, [e.target.name]: e.target.value }); 
  };

  // When user submits the form
  let handleSubmit = (e) => { // Arrow function to handle form submission
    e.preventDefault(); // Prevent default form submission behavior

    alert(
      `Order placed!\n\nName: ${form.name}\nEmail: ${form.email}\nPhone: ${form.phone}\nAddress: ${form.address}\n\nTotal: €${basketItems
        .reduce((sum, item) => sum + item.price, 0)
        .toFixed(2)}`
    );

    clearBasket(); // Now clearBasket is defined
  };

  return (
    <div className="checkout-page">
      <div className="checkout-card">
        <div className="card-header">
          <h2>Checkout</h2>
        </div>
        
        <div className="user-info">
          <p>Logged in as: {user.email}</p>
        </div>

        {/* Form for user details */}
        <form onSubmit={handleSubmit} className="checkout-form">
          <div className="form-group">
            <label>Name:</label>
            <input
              type="text"
              name="name"
              className="input"
              value={form.name}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label>Email:</label>
            <input
              type="email"
              name="email"
              className="input"
              value={form.email}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label>Phone:</label>
            <input
              type="tel"
              name="phone"
              className="input"
              value={form.phone}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label>Address:</label>
            <textarea
              name="address"
              className="input"
              value={form.address}
              onChange={handleChange}
              required
            />
          </div>

          <button className="payNow" type="submit">
            Pay Now
          </button>
        </form>
      </div>
    </div>
  );
}

export default CheckOutPage;
