// src/javascript/getFeaturedItems.js

export function getFeaturedItems(productsInput, count = 4) {
  if (!productsInput) return [];

  // Normalize to a flat array whether caller passed an object (categories) or an array
  const all =
    Array.isArray(productsInput) ? productsInput : Object.values(productsInput).flat();

  if (!all || all.length === 0) return [];

  // Prefer explicit featured flag, otherwise take first `count` items
  const featured = all.filter((p) => p && p.featured);
  if (featured.length >= count) return featured.slice(0, count);

  // Fill up with non-featured items (unique)
  const selected = [...featured];
  for (const p of all) {
    if (selected.length >= count) break;
    if (!selected.includes(p)) selected.push(p);
  }

  return selected.slice(0, count);
}
