// src/utils/phoneValidation.js
import { isValidPhoneNumber } from 'libphonenumber-js';

export function handlePhoneChange(e, setForm, setIsValid) {
  const { name, value } = e.target;
  setForm((prev) => ({ ...prev, [name]: value }));

  // Validate phone number (assuming Italy for example)
  const valid = isValidPhoneNumber(value, 'IT');
  setIsValid(valid);
}
