/* 
 * REFERENCES & DOCUMENTATION:
 * 
 * React Context API:
 * - Creating Context: https://react.dev/reference/react/createContext
 * - Context Provider: https://react.dev/reference/react/createcontext#provider
 * - useContext Hook: https://react.dev/reference/react/usecontext
 * 
 * Authentication Patterns:
 * - React Authentication: https://kentcdodds.com/blog/authentication-in-react-applications
 * - Custom Hooks: https://react.dev/learn/reusing-logic-with-custom-hooks
 */

import React, { createContext, useState, useContext } from 'react';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {// Arrow function to define AuthProvider component
    const [user, setUser] = useState(null);

    const login = (name, phoneNumber, password) => {
        // In a real app, you'd validate against a backend
        setUser({ name, phoneNumber });
    };

    const logout = () => {// Arrow function to handle user logout
        setUser(null);
    };

    return (// Render the AuthContext.Provider with the user state and auth functions 
        <AuthContext.Provider value={{ user, login, logout }}>
            {/* // Render child components within the provider */}
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = () => useContext(AuthContext);