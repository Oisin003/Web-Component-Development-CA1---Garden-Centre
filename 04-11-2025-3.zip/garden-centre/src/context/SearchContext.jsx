import React, { createContext, useState } from 'react';

export const SearchContext = createContext();
// Create and export SearchContext for managing search query state
export function SearchProvider({ children }) {// Arrow function to define SearchProvider component
    const [query, setQuery] = useState('');// State to hold current search query and updater function 
    return (// Provide search query state and updater function to children components
        <SearchContext.Provider value={{ query, setQuery }}>
            {children}
        </SearchContext.Provider>
    );
}