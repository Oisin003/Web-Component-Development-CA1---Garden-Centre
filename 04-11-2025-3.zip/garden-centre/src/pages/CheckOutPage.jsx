// src/pages/CheckoutPage.jsx

/* 
 * REFERENCES & DOCUMENTATION:
 * 
 * React Hooks & State:
 * - useState Hook: https://react.dev/reference/react/useState
 * - useContext Hook: https://react.dev/reference/react/usecontext
 * - Form Handling: https://react.dev/reference/react-dom/components/form
 * 
 * JavaScript Array Methods:
 * - Array.reduce(): https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/reduce
 * - Spread Operator: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Spread_syntax
 * 
 * Date & Number Formatting:
 * - Date.toLocaleDateString(): https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date/toLocaleDateString
 * - Math.random(): https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Math/random
 * 
 * Form Validation:
 * - Phone Number Validation: https://www.npmjs.com/package/libphonenumber-js
 */

import { useContext, useState } from "react";
import { useBasket } from "../context/BasketContext"; // Change this line
import { useCurrency } from "../context/CurrencyContext";
import { useAuth } from '../context/AuthContext';
import "../CheckOutPage.css";
// import {handlePhoneChange} from "../utils/checkPhoneNumber";
// import { isValidPhoneNumber } from 'libphonenumber-js';

const CheckOutPage = () => {// Arrow function to define CheckOutPage component
  const { basketItems, clearBasket } = useBasket(); // Add clearBasket here
  const { formatPrice } = useCurrency();
  const { user } = useAuth();
  const [showReceipt, setShowReceipt] = useState(false);
  const [orderDetails, setOrderDetails] = useState(null);
  //Phine Validation

  // const [isValid, setIsValid] = useState(null);

  // Form state for user details - pre-filled with user login info
  let [form, setForm] = useState({ // useState hook to manage form data
    name: user?.name || "",// Pre-fill name from user context if available
    email: "",// Email starts empty
    phone: user?.phoneNumber || "",
    address: "",
  }); 

  // Handle input changes
  let handleChange = (e) => { // Arrow function to handle input changes
    // Copy the existing form using pread operator then sets the key to the inputs name and sets the new value based on user input   
    setForm({ ...form, [e.target.name]: e.target.value }); 
  };

  // When user submits the form
  let handleSubmit = (e) => { // Arrow function to handle form submission
    e.preventDefault(); // Prevent default form submission behavior

    const total = basketItems.reduce((sum, item) => sum + item.price, 0);
    const orderData = {
      ...form,// Spread form data
      items: basketItems,
      total: total,// Total price calculation
      orderNumber: Math.floor(Math.random() * 1000000),// Random order number
      date: new Date().toLocaleDateString()// Format date as per locale
    };

    setOrderDetails(orderData);// Set order details state
    setShowReceipt(true);// Show receipt modal
    clearBasket(); // Clear basket after successful order
  };

  const closeReceipt = () => {// Arrow function to close receipt modal
    setShowReceipt(false);// Close the receipt modal
    setOrderDetails(null);// Clear order details
  };

  return (
    <div className="checkout-page">
      <div className="checkout-card">
        <div className="card-header">
          <h2>Checkout</h2>
        </div>
        
        <div className="user-info">
          <p>Logged in as: {user.name} ({user.phoneNumber})</p>
        </div>

        {/* Form for user details */}
        <form onSubmit={handleSubmit} className="checkout-form">
          <div className="form-group">
            <label>Name:</label>
            <input
              type="text"
              name="name"
              className="input"
              value={form.name}
              onChange={handleChange}
              required
              readOnly
              style={{ backgroundColor: '#f5f5f5', cursor: 'not-allowed' }}
            />
          </div>

          <div className="form-group">
            <label>Email:</label>
            <input
              type="email"
              name="email"
              className="input"
              value={form.email}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label>Phone:</label>
            <input
              type="tel"
              name="phone"
              className="input"
              value={form.phone}
              onChange={handleChange}
              required
              readOnly
              style={{ backgroundColor: '#f5f5f5', cursor: 'not-allowed' }}
            />
          </div>

          <div className="form-group">
            <label>Address:</label>
            <textarea
              name="address"
              className="input"
              value={form.address}
              onChange={handleChange}
              required
            />
          </div>

          <button className="payNow" type="submit">
            Pay Now
          </button>
        </form>
      </div>

      {/* Receipt Modal */}
      {showReceipt && orderDetails && (// If showReceipt is true and orderDetails exist
        <div className="receipt-overlay" style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          zIndex: 1000
        }}>
          <div className="receipt-card" style={{
            backgroundColor: 'white',
            padding: '30px',
            borderRadius: '15px',
            maxWidth: '500px',
            width: '90%',
            maxHeight: '80vh',
            overflowY: 'auto',
            boxShadow: '0 10px 30px rgba(0, 0, 0, 0.3)',
            position: 'relative'
          }}>
            <div style={{ textAlign: 'center', marginBottom: '20px' }}>
              <h2 style={{ color: '#28a745', marginBottom: '10px' }}>✓ Order Confirmed!</h2>
              <p style={{ color: '#666', margin: 0 }}>Thank you for your purchase</p>
            </div>

            <div style={{ 
              backgroundColor: '#f8f9fa', 
              padding: '15px', 
              borderRadius: '8px', 
              marginBottom: '20px' 
            }}>
              <h3 style={{ margin: '0 0 10px 0', fontSize: '16px' }}>Order Details</h3>
              <p style={{ margin: '5px 0' }}><strong>Order #:</strong> {orderDetails.orderNumber}</p>
              <p style={{ margin: '5px 0' }}><strong>Date:</strong> {orderDetails.date}</p>
            </div>

            <div style={{ marginBottom: '20px' }}>
              <h3 style={{ margin: '0 0 10px 0', fontSize: '16px' }}>Customer Information</h3>
              <p style={{ margin: '5px 0' }}><strong>Name:</strong> {orderDetails.name}</p>
              <p style={{ margin: '5px 0' }}><strong>Email:</strong> {orderDetails.email}</p>
              <p style={{ margin: '5px 0' }}><strong>Phone:</strong> {orderDetails.phone}</p>
              <p style={{ margin: '5px 0' }}><strong>Address:</strong> {orderDetails.address}</p>
            </div>

            <div style={{ marginBottom: '20px' }}>
              <h3 style={{ margin: '0 0 10px 0', fontSize: '16px' }}>Items Ordered</h3>
              {orderDetails.items.map((item, index) => (
                <div key={index} style={{ 
                  display: 'flex', 
                  justifyContent: 'space-between', 
                  padding: '8px 0',
                  borderBottom: index < orderDetails.items.length - 1 ? '1px solid #eee' : 'none'
                }}>
                  <span>{item.name}</span>
                  <span>{formatPrice(item.price)}</span>
                </div>
              ))}
            </div>

            <div style={{ 
              borderTop: '2px solid #28a745', 
              paddingTop: '15px', 
              marginBottom: '20px' 
            }}>
              <div style={{ 
                display: 'flex', 
                justifyContent: 'space-between', 
                fontSize: '18px', 
                fontWeight: 'bold',
                color: '#28a745'
              }}>
                <span>Total:</span>
                <span>{formatPrice(orderDetails.total)}</span>
              </div>
            </div>

            <button 
              onClick={closeReceipt}
              style={{
                width: '100%',
                padding: '12px',
                backgroundColor: '#28a745',
                color: 'white',
                border: 'none',
                borderRadius: '8px',
                fontSize: '16px',
                cursor: 'pointer'
              }}
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default CheckOutPage;
