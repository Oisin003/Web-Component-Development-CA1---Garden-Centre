// src/pages/ProductsPage.jsx
import React, { useContext, useEffect, useState } from "react";
import ProductCard from "../components/ProductCard";
import { products } from "../data/stock";
import { SearchContext } from "../context/SearchContext";

export default function ProductsPage({ category }) {
  const { query } = useContext(SearchContext);
  const q = (query || "").trim().toLowerCase();

  // State to hold products to render (either category items or search results)
  let [items, setItems] = useState([]);

  useEffect(() => {// Effect hook to update items when category or search query changes
    if (q) {
      // search across all categories
      const all = Object.values(products).flat();// Flatten all product arrays into one
      const results = all.filter((p) => p.name.toLowerCase().includes(q));//  Filter products matching the search query
      setItems(results);
    } else {
      // show items for selected category (or empty array if category missing)
      setItems(products[category] || []);
    }
  }, [category, q]);

  return (
    <section>
      <h2 className="pageHeaders">{q ? `Search: "${query}"` : category}</h2>
      <div className="product-grid">
        {items.length > 0 ? (
          items.map((p) => (
            <ProductCard key={p.id} item={p} />
          ))
        ) : (
          <ProductCard placeholderMessage={`Sorry, "${query}" is out of stock`} />
        )}
      </div>
    </section>
  );
}
