// Currency Selector Component
// L00172671
// Oisin Gibson

import React, { useState, useEffect, useRef } from 'react';
import { useCurrency } from '../context/CurrencyContext';
import './CurrencySelector.css';

const CurrencySelector = () => {
  const { selectedCurrency, currencies, changeCurrency, currentCurrency } = useCurrency();
  const [isOpen, setIsOpen] = useState(false);
  const [dropdownPosition, setDropdownPosition] = useState({ top: 0, right: 0 });
  const dropdownRef = useRef(null);
  const buttonRef = useRef(null);

  // Calculate dropdown position when opening
  const handleToggle = () => {
    if (!isOpen && buttonRef.current) {
      const rect = buttonRef.current.getBoundingClientRect();
      setDropdownPosition({
        top: rect.bottom + 4,
        right: window.innerWidth - rect.right
      });
    }
    setIsOpen(!isOpen);
  };

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleCurrencyChange = (currencyCode) => {
    changeCurrency(currencyCode);
    setIsOpen(false);
  };

  return (
    <div className="currency-selector" ref={dropdownRef}>
      <button 
        ref={buttonRef}
        className="currency-toggle"
        onClick={handleToggle}
        aria-label="Select currency"
        aria-expanded={isOpen}
      >
        <span className="currency-display">
          <span className="currency-symbol">{currentCurrency.symbol}</span>
          <span className="currency-code">{selectedCurrency}</span>
        </span>
        <svg 
          className={`dropdown-arrow ${isOpen ? 'open' : ''}`}
          width="12" 
          height="12" 
          viewBox="0 0 24 24" 
          fill="none" 
          stroke="currentColor" 
          strokeWidth="2"
        >
          <polyline points="6,9 12,15 18,9"></polyline>
        </svg>
      </button>

      {isOpen && (
        <div 
          className="currency-dropdown"
          style={{
            position: 'fixed',
            top: `${dropdownPosition.top}px`,
            right: `${dropdownPosition.right}px`,
            zIndex: 10001
          }}
        >
          <div className="currency-list">
            {Object.entries(currencies).map(([code, currency]) => (
              <button
                key={code}
                className={`currency-option ${code === selectedCurrency ? 'selected' : ''}`}
                onClick={() => handleCurrencyChange(code)}
              >
                <span className="currency-info">
                  <span className="currency-symbol-option">{currency.symbol}</span>
                  <span className="currency-details">
                    <span className="currency-code-option">{code}</span>
                    <span className="currency-name">{currency.name}</span>
                  </span>
                </span>
                {code === selectedCurrency && (
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <polyline points="20,6 9,17 4,12"></polyline>
                  </svg>
                )}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default CurrencySelector;
