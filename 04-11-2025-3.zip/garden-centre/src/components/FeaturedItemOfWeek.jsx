// Oisin Gibson
// L00172671
// src/components/FeaturedItemOfWeek.jsx
// Featured Item of the Week - Resets every Sunday

import React, { useState, useEffect } from 'react';
import { products } from '../data/stock';
import { useCurrency } from '../context/CurrencyContext';
import ProductCard from './ProductCard';
import './FeaturedItemOfWeek.css';

const FeaturedItemOfWeek = () => {// Arrow function to define FeaturedItemOfWeek component
    // State to hold the featured item - Null initially
  const [featuredItem, setFeaturedItem] = useState(null);
  // State to hold the countdown timer - String initially
  const [timeLeft, setTimeLeft] = useState('');
  const [weekNumber, setWeekNumber] = useState(0);// State to hold the current week number - 0 initially
  
  // Access currency formatting functions
  const { formatPrice } = useCurrency();

  // Get the start of the current week (Sunday)
  const getWeekStart = (date = new Date()) => {// Arrow function to get week start
    const d = new Date(date);// Create a new date object
    const day = d.getDay();// Get the current day of the week (0-6)
    const diff = d.getDate() - day;// Calculate difference to get to Sunday
    return new Date(d.setDate(diff));// Return new date set to the start of the week
  };

  // Get the end of the current week (Saturday 11:59 PM)
  const getWeekEnd = (date = new Date()) => {// Arrow function to get week end
    const weekStart = getWeekStart(date);// Get the start of the week
    const weekEnd = new Date(weekStart);// Create new date object for week end
    weekEnd.setDate(weekStart.getDate() + 6);// Set date to Saturday
    weekEnd.setHours(23, 59, 59, 999);/// Set time to end of day
    return weekEnd;// Return the week end date
  };

  // Get week number from date
  // Reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Math/ceil
  // Math.ceil() function always rounds up to the nearest integer
  const getWeekNumber = (date = new Date()) => {// Arrow function to get week number
    const startOfYear = new Date(date.getFullYear(), 0, 1);// Get the first day of the year (January 1st)
    const pastDaysOfYear = (date - startOfYear) / 86400000;// Calculate past days in the year (milliseconds to days conversion: 86400000ms = 1 day)
    // Math.ceil() rounds UP to nearest whole number - ensures partial weeks count as full weeks
    // Example: 6.2 days becomes week 7, 6.9 days becomes week 7
    // Formula explanation: (days passed + day of week offset + 1) / 7 days per week
    // startOfYear.getDay() adjusts for what day of week January 1st falls on (0=Sunday, 6=Saturday)
    return Math.ceil((pastDaysOfYear + startOfYear.getDay() + 1) / 7);// Return the calculated week number
  };

  // Select featured item based on week number
  // References: 
  // Object.values(): https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/values
  // Array.flat(): https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/flat
  const selectFeaturedItem = () => {// Arrow function to select featured item
    // Object.values() extracts all values from the products object (ignoring keys like "Plants", "Tools", "Garden Care")
    // This returns an array of arrays: [[plant1, plant2...], [tool1, tool2...], [care1, care2...]]
    // flat() method flattens nested arrays into a single array - removes one level of nesting
    // Example: [[1,2], [3,4], [5,6]].flat() becomes [1,2,3,4,5,6]
    const allProducts = Object.values(products).flat();// Flatten all product arrays into one - single array of products
    const currentWeek = getWeekNumber();//  Get the current week number
    setWeekNumber(currentWeek);// Update state with current week number
    
    // Use week number as seed for consistent selection
    // Reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Remainder
    // Modulus operator (%) returns the remainder of division - ensures index stays within array bounds
    // Example: if currentWeek=45 and allProducts.length=37, then 45%37=8, so index=8
    const index = currentWeek % allProducts.length;// Calculate index using modulus
    const selected = allProducts[index];// Select the featured item at calculated index
    
    // Add special weekly discount
    // Reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Spread_syntax
    // Spread operator (...) copies all properties from the original object
    const discountedItem = {// Create discounted item object
      ...selected,// Spread operator to copy all properties from selected item (id, name, price, images, etc.)
      originalPrice: selected.price, // Store original price for price comparison display
      price: selected.price * 0.8, // Apply 20% discount (multiply by 0.8 = 80% of original price)
      isWeeklyFeatured: true// Add flag to mark this item as the weekly featured item
    };
    
    setFeaturedItem(discountedItem);
  };

  // Update countdown timer
  // Reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Math/floor
  // Math.floor() rounds DOWN to the nearest integer (opposite of Math.ceil())
  const updateCountdown = () => {// Arrow function to update countdown timer
    const now = new Date();// Get current date and time
    const weekEnd = getWeekEnd();// Get the end of current week (Saturday 11:59 PM)
    const difference = weekEnd - now;// Calculate time difference in milliseconds

    if (difference > 0) {// If week hasn't ended yet
      // Convert milliseconds to human-readable time units
      // 1000ms = 1 second, 60s = 1 minute, 60m = 1 hour, 24h = 1 day
      const days = Math.floor(difference / (1000 * 60 * 60 * 24));// Calculate remaining days
      const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));// Calculate remaining hours
      const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));// Calculate remaining minutes
      const seconds = Math.floor((difference % (1000 * 60)) / 1000);// Calculate remaining seconds

      // Template literal to format countdown display
      setTimeLeft(`${days}d ${hours}h ${minutes}m ${seconds}s`);// Update countdown state
    } else {
      // Week has ended, select new item
      selectFeaturedItem();// Automatically select new featured item for next week
    }
  };

  // Initialize featured item and countdown
  // Reference: https://react.dev/reference/react/useEffect
  // useEffect runs side effects - code that affects things outside the component
  useEffect(() => {// Hook that runs after component mounts and on dependency changes
    selectFeaturedItem();// Select initial featured item when component first loads
    updateCountdown();// Start countdown timer immediately
    
    // Update countdown every second
    // Reference: https://developer.mozilla.org/en-US/docs/Web/API/setInterval
    // setInterval repeatedly calls a function with a fixed time delay between calls
    const timer = setInterval(updateCountdown, 1000);// Update countdown every 1000ms (1 second)
    
    // Cleanup function to prevent memory leaks
    // Reference: https://react.dev/reference/react/useEffect#useeffect-cleanup
    // Return function runs when component unmounts or before effect runs again
    return () => clearInterval(timer);// Clear the interval timer when component unmounts
  }, []);// Empty dependency array means this effect only runs once on mount

  // Early return pattern - guard clause to prevent rendering if no featured item
  // Reference: https://react.dev/learn/conditional-rendering
  if (!featuredItem) return null;// Return null if featuredItem is null/undefined (prevents errors)

  // JSX Return - the component's visual structure
  // Reference: https://react.dev/learn/writing-markup-with-jsx
  return (
    <div className="featured-item-container">
      <div className="featured-header">
        <div className="featured-badge">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 16 16">
            <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.282.95l-3.522 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z"/>
          </svg>
          Featured Item of the Week
        </div>
        <div className="week-info">
          <span className="week-number">Week {weekNumber}</span>
          <div className="countdown">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
              <path d="M8 3.5a.5.5 0 0 0-1 0V9a.5.5 0 0 0 .252.434l3.5 2a.5.5 0 0 0 .496-.868L8 8.71z"/>
              <path d="M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16m7-8A7 7 0 1 1 1 8a7 7 0 0 1 14 0"/>
            </svg>
            {timeLeft}
          </div>
        </div>
      </div>

      <div className="featured-content">
        <div className="featured-card-wrapper">
          <div className="discount-tag">
            <span className="discount-percent">20% OFF</span>
            <span className="discount-text">This Week Only!</span>
          </div>
          
          <div className="featured-product-card">
            <ProductCard item={featuredItem} />
            <div className="price-comparison">
              {/* Price display with original, sale, and savings amounts */}
              {/* toFixed(2) formats number to 2 decimal places for currency display */}
              <span className="original-price">€{featuredItem.originalPrice.toFixed(2)}</span>
              <span className="sale-price">€{featuredItem.price.toFixed(2)}</span>
              {/* Calculate savings by subtracting discounted price from original */}
              <span className="savings">Save €{(featuredItem.originalPrice - featuredItem.price).toFixed(2)}</span>
            </div>
          </div>
        </div>

        <div className="featured-details">
          <h3>Why This Week's Pick?</h3>
          <div className="feature-highlights">
            {/* Call function to generate item-specific highlights */}
            {getItemHighlights(featuredItem)}
          </div>
          
          <div className="weekly-tip">
            <h4>
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" viewBox="0 0 16 16">
                <path d="M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16m.93-9.412-1 4.705c-.07.34.029.533.304.533.194 0 .487-.07.686-.246l-.088.416c-.287.346-.92.598-1.465.598-.703 0-1.002-.422-.808-1.319l.738-3.468c.064-.293.006-.399-.287-.47l-.451-.081.082-.381 2.29-.287zM8 5.5a1 1 0 1 1 0-2 1 1 0 0 1 0 2"/>
              </svg>
              Weekly Care Tip
            </h4>
            {/* Call function to get seasonal care advice for this item */}
            <p>{getWeeklyCareTitle(featuredItem)}</p>
          </div>
        </div>
      </div>

      <div className="featured-cta">
        <p>Don't miss out! This special offer resets every Sunday at midnight.</p>
        <div className="social-share">
          <span>Share this deal:</span>
          {/* Event handlers call shareOnSocial function with platform parameter */}
          {/* Arrow functions used to pass parameters to event handlers */}
          <button className="share-btn facebook" onClick={() => shareOnSocial('facebook')}>
            Share
          </button>
          <button className="share-btn twitter" onClick={() => shareOnSocial('twitter')}>
            Tweet
          </button>
        </div>
      </div>
    </div>
  );
};

// Get item-specific highlights
const getItemHighlights = (item) => {// Arrow function to get highlights for the item
  const highlights = {
    // Plants
    'Rose': ['Perfect for romantic gardens', 'Blooms multiple times per year', 'Attracts beneficial pollinators'],
    'Tulip': ['Early spring color', 'Low maintenance bulb', 'Great for beginners'],
    'Orchid': ['Exotic indoor beauty', 'Long-lasting blooms', 'Air purifying qualities'],
    'Lavender': ['Calming fragrance', 'Drought tolerant', 'Natural pest deterrent'],
    
    // Tools
    'Shovel': ['Essential garden tool', 'Durable construction', 'Ergonomic design'],
    'Pruning Shears': ['Clean, precise cuts', 'Promotes healthy growth', 'Professional quality'],
    'Wheelbarrow': ['Heavy-duty transport', 'Saves your back', 'Weather resistant'],
    
    // Care
    'Fertilizer': ['Boosts plant growth', 'Organic formula', 'Season-long nutrition'],
    'Compost': ['Improves soil health', 'Eco-friendly choice', 'Natural nutrients']
  };
  
  // Logical OR operator (||) provides fallback if item not found in highlights object
  // Reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Logical_OR
  const itemHighlights = highlights[item.name] || ['High quality product', 'Expert recommended', 'Great value for money'];// Default highlights if none found
  
  // Array.map() transforms each highlight string into a JSX element
  // Reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/map
  return itemHighlights.map((highlight, index) => (// Map each highlight to a JSX element
    <div key={index} className="highlight-item">
      {/* Checkmark SVG icon for each highlight */}
      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
        <path d="M10.97 4.97a.235.235 0 0 0-.02.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.061L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-1.071-1.05"/>
      </svg>
      {highlight}
    </div>
  ));
};

// Get weekly care tip based on item type
const getWeeklyCareTitle = (item) => {// Arrow function to get care tip for the item
  const tips = {
    'Rose': 'November is perfect for planting bare-root roses. Water well and mulch around the base.',
    'Tulip': 'Plant tulip bulbs now for spring blooms. Ensure good drainage to prevent rot.',
    'Orchid': 'Reduce watering frequency as temperatures drop. Maintain humidity with a pebble tray.',
    'Lavender': 'Cut back spent flower stems but avoid hard pruning in late autumn.',
    'Shovel': 'Clean and oil your tools before winter storage to prevent rust and maintain sharpness.',
    'Fertilizer': 'Apply winter fertilizer now to help plants build strong root systems for spring.',
    'Compost': 'Add autumn leaves to your compost for a perfect carbon-nitrogen balance.'
  };
  
  return tips[item.name] || 'This week is ideal for general garden maintenance and preparation for the coming season.';
};

// Social sharing functionality
// Reference: https://developer.mozilla.org/en-US/docs/Web/API/Window/open
// window.open() opens a new browser window/tab with specified URL
const shareOnSocial = (platform) => {// Arrow function to share on social media
  const url = window.location.href;// Get current page URL for sharing
  const text = `Check out this week's featured garden item with 20% off!`;// Share message text
  
  // Conditional logic to handle different social media platforms
  if (platform === 'facebook') {
    // Facebook Sharer API - opens Facebook share dialog
    // encodeURIComponent() safely encodes URL for use in query parameters
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`, '_blank');
  } else if (platform === 'twitter') {
    // Twitter Intent API - opens Twitter compose tweet dialog
    window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`, '_blank');
  }
};

export default FeaturedItemOfWeek;