// src/utils/getFeaturedItems.js

/* 
 * REFERENCES & DOCUMENTATION:
 * 
 * JavaScript Array Methods:
 * - Array.isArray(): https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/isArray
 * - Array.filter(): https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/filter
 * - Array.slice(): https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/slice
 * - Object.values(): https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/values
 * - Spread Operator: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Spread_syntax
 * 
 * Algorithm Design:
 * - Array Normalization Patterns: https://javascript.info/array-methods
 * - Data Filtering Strategies: https://www.freecodecamp.org/news/javascript-array-filter-tutorial/
 * - Default Parameters: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Functions/Default_parameters
 */

// Utility function to extract featured items from product collections
// Supports both array and object (categorized) product structures
export function getFeaturedItems(productsInput, count = 4) {
  // Guard clause: return empty array if no products provided
  if (!productsInput) return [];

  // Normalize to a flat array whether caller passed an object (categories) or an array
  // This pattern allows flexibility in data structure handling
  const all =
    Array.isArray(productsInput) ? productsInput : Object.values(productsInput).flat();

  // Additional validation for empty or invalid data
  if (!all || all.length === 0) return [];

  // --- Mark "new" products (added in last 7 days) ---
  // Reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date/now
  // Date.now() returns current timestamp in milliseconds since Unix epoch (Jan 1, 1970)
  const DAYS_NEW = 7; // Threshold for considering a product "new" (7 days)
  const now = Date.now(); // Current timestamp in milliseconds
  
  // Iterate through all products to calculate and mark new items
  // Reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/forEach
  all.forEach((p) => {// For each product, check dateAdded to determine if it's new
    if (p && p.dateAdded) {// Ensure product and dateAdded exist (defensive programming)
      // Calculate product age in days using timestamp arithmetic
      // Reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date/Date
      // new Date(p.dateAdded) converts string/ISO date to Date object, then to milliseconds
      // Milliseconds to days conversion: divide by (1000ms * 60sec * 60min * 24hr)
      const daysOld = (now - new Date(p.dateAdded)) / (1000 * 60 * 60 * 24);// Calculate age in days
      
      // Mark product as new if it's within the threshold
      // Reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Less_than_or_equal
      p.isNew = daysOld <= DAYS_NEW;// Mark as new if within threshold (7 days or less)
    }
  });

  // Filter products that have been manually marked as featured
  const featured = all.filter((p) => p && p.featured);
  if (featured.length >= count) return featured.slice(0, count);

  // Get non-featured products, sorted by rating (descending)
  let nonFeatured = all.filter((p) => p && !p.featured);
  nonFeatured.sort((a, b) => (b.rating || 0) - (a.rating || 0));

  // --- Innovation 1: Shuffle non-featured for variety ---
  for (let i = nonFeatured.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [nonFeatured[i], nonFeatured[j]] = [nonFeatured[j], nonFeatured[i]];
  }

  // Fill up with non-featured, highest rating first, random order
  const selected = [...featured];
  for (const p of nonFeatured) {
    if (selected.length >= count) break;
    if (!selected.includes(p)) selected.push(p);
  }

  // Return exactly the requested count (or fewer if not enough products)
  return selected.slice(0, count);
}
