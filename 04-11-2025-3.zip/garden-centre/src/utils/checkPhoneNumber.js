// src/utils/phoneValidation.js
import { isValidPhoneNumber } from 'libphonenumber-js';

export function handlePhoneChange(e, setForm, setIsValid) {// Arrow function to handle phone number input changes
  const { name, value } = e.target;// Destructure name and value from event target
  setForm((prev) => ({ ...prev, [name]: value }));// Update form state with new phone number value

  // Validate phone number (assuming Italy for example)
  const valid = isValidPhoneNumber(value, 'IT');// Check if phone number is valid for Italian format  
  setIsValid(valid);// Update validity state
}
