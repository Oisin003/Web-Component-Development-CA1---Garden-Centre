// Oisin Gibson
// L00172671
// src/App.jsx
// Import routing components (only Routes and Route — no need for BrowserRouter here)
import { Routes, Route } from "react-router-dom";
// Import shared layout components
import Header from "./components/Header";
import Footer from "./components/Footer";
// Import page components
import Home from "./pages/Home";
import ProductsPage from "./pages/ProductsPage";
import BasketPage from "./pages/BasketPage";
import CheckoutPage from "./pages/CheckOutPage";
// Import context provider for basket state
import { BasketProvider } from "./context/BasketContext";
// Import global styles
import "./App.css";

function App() {
  return (
    // Wrap the app inside BasketProvider so all components can access basket state
    <BasketProvider>
      {/* Header is always visible */}
      <Header />
      {/* Main content area where routed pages will appear */}
      <main className="main-content">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/plants" element={<ProductsPage category="Plants" />} />
          <Route path="/tools" element={<ProductsPage category="Tools" />} />
          <Route path="/garden-care" element={<ProductsPage category="Garden Care" />} /> 
          <Route path="/basket" element={<BasketPage />} />
          <Route path="/checkout" element={<CheckoutPage />} />
        </Routes>
      </main>
      {/* Footer is always visible */}
      <Footer />
    </BasketProvider>
  );
}

export default App;
