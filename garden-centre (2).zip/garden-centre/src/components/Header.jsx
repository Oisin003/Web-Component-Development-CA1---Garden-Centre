// Oisin Gibson
// L00172671
// src/components/Header.jsx
import React from 'react';
import logo from '../images/logo/logo.jpg';
import '../App.css';
import { Link } from 'react-router-dom';


function Header() {
  return (
    <header>
      {/* Top Bar */}
      <div className="top-bar">
        <p> Call us: 074-9121541 / 074-9121545 | NI: 00 353 74 9121541 | Orders by phone only</p>
      </div>

      {/* Logo + Slogan */}
      <div className="logo-bar">
        <img src={logo} alt="Garden Centre Logo" className="logo-banner" />
        <div className="logo-text">
          <h1>Tropical World Garden Centre</h1>
          <p>Your one-stop shop for all things gardening!</p>
        </div>
      </div>

      {/* Navigation */}
      <nav className="main-nav">
        <ul className="nav-menu">
          <li><Link to="/" className="nav-btn">Home</Link></li>
          <li><Link to="/plants" className="nav-btn">Plants</Link></li><i class="bi bi-flower3"></i>
          <li><Link to="/garden-care" className="nav-btn">Garden Care</Link></li>
          <li><Link to="/tools" className="nav-btn">Tools</Link></li><i class="bi bi-hammer"></i>
          <li><Link to="/basket" className="nav-btn">Basket</Link></li><i class="bi bi-basket2-fill"></i>
        </ul>
      </nav>
    </header>
  );
}

export default Header;


