// Oisin Gibson
// L00172671
// src/context/BasketContext.jsx
import { createContext, useState } from "react";
// Create a new Context for the shopping basket
export let BasketContext = createContext();

// This provider wraps the app and shares basket data with all components
export function BasketProvider({ children }) {
  // useState hook stores all items currently in the basket
 // Create Variable, Function to Update state, initial empty array[] 
  let [basketItems, setBasketItems] = useState([]);
  // Function to add an item to the basket
  let addToBasket = (item) => { //Arrow function to add an item to the basket
    setBasketItems((prevItems) => [...prevItems, item]);
  };

  // Function to remove an item by its ID
  let removeFromBasket = (id) => { //Arrow function to remove an item from the basket by its ID
    setBasketItems((prevItems) => prevItems.filter((item) => item.id !== id));
  };

  // Function to clear basket after checkout
  let clearBasket = () => { //Arrow function to clear the basket
    setBasketItems([]);
  };

  // Provide both data and functions to all children components
  return (
    // https://react.dev/reference/react/useContext
    // This component shares basket-related data and functions with all its child components (React Context API)
    <BasketContext.Provider
      value={{
        basketItems,       // The current contents of the basket 
        addToBasket,       // Function to add a product to the basket
        removeFromBasket,  // Function to remove a product from the basket
        clearBasket        // Function to empty the basket completely
      }}
    >
      {/* Render all child components that are wrapped inside BasketProvider */}
      {children}
    </BasketContext.Provider>
  );

}
