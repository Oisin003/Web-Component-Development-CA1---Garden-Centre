gardenPlants = [
    { id: 1, name: 'Rose', price: 10.0, image: 'https://encrypted-tbn0.gstatic.com/shopping?q=tbn:ANd9GcQy5Di0K1lNis3tzkHTUw6v5uA-_-s9oDUSM3ezLnciHjtniXgD9xynBnf0WlPex5C1-0AXQyiSA9_5HdxbliaGB7YgCVVmLac3zEH6yKmogjKFdxUxtx2aBwEjBTLD0kfp9Lh1uA&usqp=CAc' },
    { id: 2, name: 'Tulip', price: 5.0, image: 'https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcQqse9Tq2XT6rLqnIRqHGt136ooS4KUhCGEYnq1Gy0UWa4IGNHRR1CnyCvvYisQnWkTaZxv-ceM5WjP-lnNWyuRveou8jf73Yee8rVgqhJBRlQwrR0u8SyhQsstvaLg9k-XwaOKDQ&usqp=CAc' },
    { id: 3, name: 'Daffodil', price: 7.0, image: 'https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcSVnl1HYXBaThP2TNkHndbvNCMznZ0yVIqejgmhTiK-cIwPn0HxXaNFxzaRQWoxIzso1CkTJvN_p0vn1s51eeW-VIueW7nWxZye_FGKcr6T&usqp=CAc' },
    { id: 4, name: 'Sunflower', price: 8.0, image: '' },
    { id: 5, name: 'Lily', price: 12.0 },
    { id: 6, name: 'Orchid', price: 20.0 },
    { id: 7, name: 'Daisy', price: 4.0 },
    { id: 8, name: 'Marigold', price: 6.0 },
    { id: 9, name: 'Lavender', price: 15.0 },
    { id: 10, name: 'Hyacinth ', price: 9.0 }
]
export default gardenPlants;