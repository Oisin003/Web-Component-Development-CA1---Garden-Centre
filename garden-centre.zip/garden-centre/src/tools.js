gardenTools = [
    { id: 1, name: 'Shovel', price: 25.0, },
    { id: 2, name: 'Rake', price: 15.0 },
    { id: 3, name: 'Hoe', price: 20.0 },
    { id: 4, name: 'Pruners', price: 30.0 },
    { id: 5, name: 'Trowel', price: 10.0 },
    { id: 6, name: 'Wheelbarrow', price: 100.0 },
    { id: 7, name: 'Garden Fork', price: 35.0 },
    { id: 8, name: 'Gloves', price: 12.0 },
    { id: 9, name: 'Watering Can', price: 18.0 },
    { id: 10, name: 'Lawn Mower', price: 250.0 }
]
export default gardenTools;