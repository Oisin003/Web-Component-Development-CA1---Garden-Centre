// Oisin Gibson
// L00172671
// src/components/ProductCard.jsx

// Import React hooks
import { useContext, useState } from "react";

// Import the basket context to access shared basket functions and data
import { BasketContext } from "../context/BasketContext";

// Import styles specific to the product card
import "../ProductCard.css";

// Define the ProductCard component + receive product details as props
export default function ProductCard({ id, name, price, images }) {
  // Access basket-related functions and data from context
  let { addToBasket, removeFromBasket, basketItems } = useContext(BasketContext);
  //Example of a Hook to create a piece of local state
  // Variable, Function, Set it to false 
  let [added, setAdded] = useState(false);

  // Handle button click (arrow function)
  let handleAdd = () => {
    if (added) {
      // If already added, remove it from the basket
      removeFromBasket(id);
    } else {
      // If not added yet, add it to the basket
      addToBasket({ id, name, price, images });
    }
    // Flip the local state to reflect the change
    setAdded(!added);
  };

  // Render the product card UI
  return (
    <div className="product-card">
      {/* Display product image */}
      <img src={images[0]} alt={name} />

      {/* Display product name */}
      <h3>{name}</h3>

      {/* Display formatted price */}
      <p>€{price.toFixed(2)}</p>

      {/* Button to add or remove product from basket */}
      <button className= "cardButton" onClick={handleAdd}>
        {added ? "Remove from Basket" : "Add to Basket"}
        {/* If added is true, show "Remove from Basket" Otherwise, show "Add to Basket" */}
      </button>
    </div>
  );
}
