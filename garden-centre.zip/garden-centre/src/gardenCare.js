gardenCare = [
    { id: 1, name: 'Tree Ties', price: 1.29, image: 'https://www.thegardenshop.ie/images/thumbnails/200/200/detailed/2/45cm-rubber-tree-ties.jpg' },
    { id: 2, name: 'Spiral Tree Guards', price: 4.99, image: 'https://www.thegardenshop.ie/images/thumbnails/200/200/detailed/2/spiral-tree-guard-60cm.jpg' },
    { id: 3, name: 'Flower Sticks', price: 4.95, image: 'https://www.thegardenshop.ie/images/thumbnails/200/200/detailed/3/flower-sticks.jpg' },
    { id: 4, name: 'Multi Purpose Compost', price: 12.99, image: 'https://www.thegardenshop.ie/images/thumbnails/200/200/detailed/20/TGS_BLUE_10100082_v0_WT.jpg' },
    { id: 5, name: 'Garden Netting', price: 2.29, image: 'https://www.thegardenshop.ie/images/thumbnails/200/200/detailed/4/garden-netting-3.jpg' },
    { id: 6, name: 'Orchid Plant Supports', price: 3.29, image: 'https://www.thegardenshop.ie/images/thumbnails/200/200/detailed/5/orchid-stem-plant-supports.jpg' },
    { id: 7, name: 'Rubber Tree Strap', price: 1.19, image: 'https://www.thegardenshop.ie/images/thumbnails/200/200/detailed/5/rubber-tree-strap-2.5cm.jpg' },
    { id: 8, name: 'Farmyard Manure', price: 10.99, image: 'https://www.thegardenshop.ie/images/thumbnails/200/200/detailed/20/PA_11500006_v0_WT.jpg' },
    { id: 9, name: 'Pre-Baited Mouse Traps', price: 4.49, image: 'https://www.thegardenshop.ie/images/thumbnails/200/200/detailed/7/mouse-traps.jpg' },
    { id: 10, name: '6ft Wooden Tree Stakes', price: 3.99, image: 'https://www.thegardenshop.ie/images/thumbnails/200/200/detailed/17/wooden-tree-stake.jpg' }
]
export default gardenCare;