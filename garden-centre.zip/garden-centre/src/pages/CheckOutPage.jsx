// src/pages/CheckoutPage.jsx
import { useContext, useState } from "react";
import { BasketContext } from "../context/BasketContext";

export default function CheckoutPage() { // CheckoutPage component
  let { basketItems, clearBasket } = useContext(BasketContext); // Access basket items and clear function from context

  // Form state for user details
  let [form, setForm] = useState({ // useState hook to manage form data
    name: "",
    email: "",
    phone: "",
    address: "",
  }); 

  // Handle input changes
  let handleChange = (e) => { // Arrow function to handle input changes
    // Copy the existing form using pread operator then sets the key to the inputs name and sets the new value based on user input   
    setForm({ ...form, [e.target.name]: e.target.value }); 
  };

  // When user submits the form
  let handleSubmit = (e) => { // Arrow function to handle form submission
    e.preventDefault(); // Prevent default form submission behavior

    alert(
      `Order placed!\n\nName: ${form.name}\nEmail: ${form.email}\nPhone: ${form.phone}\nAddress: ${form.address}\n\nTotal: €${basketItems
        .reduce((sum, item) => sum + item.price, 0)
        .toFixed(2)}`
    );

    clearBasket(); // Empty basket after order is placed
  };

  return (
    <section className="checkout-page">
      <h2>Checkout</h2>

      {/* Form for user details */}
      <form onSubmit={handleSubmit} className="checkout-form">
        <label>Name:</label>
        <input type="text" name="name" value={form.name} onChange={handleChange} required />

        <label>Email:</label>
        <input type="email" name="email" value={form.email} onChange={handleChange} required />

        <label>Phone:</label>
        <input type="tel" name="phone" value={form.phone} onChange={handleChange} required />

        <label>Address:</label>
        <textarea name="address" value={form.address} onChange={handleChange} required />

        <button type="submit">Pay Now</button>
      </form>
    </section>
  );
}
