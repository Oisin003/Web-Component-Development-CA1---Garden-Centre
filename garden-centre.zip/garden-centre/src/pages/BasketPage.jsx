// src/pages/BasketPage.jsx
import { useContext } from "react";
import { Link } from "react-router-dom";
import { BasketContext } from "../context/BasketContext";
// import { products } from "../data/stock";
import "../ProductCard.css"
// import ProductCard from "../components/ProductCard";

export default function BasketPage() {
  let { basketItems, removeFromBasket } = useContext(BasketContext);

  // Calculate total price dynamically
  let total = basketItems.reduce((sum, item) => sum + item.price, 0); // Sum up the prices of all items in the basket

  return (
    <section className="basket-page">
      <h2>Basket</h2>

      {basketItems.length === 0 ? ( // Check if the basket is empty
        <p>Basket is empty.</p>
      ) : (
        <>
            {/* <ProductCard /> */}
            <ul>

              {basketItems.map((item) => ( // Map over each item in the basket and display its details
                <li key={item.id}> {/* Unique key for each item */}
                 <div className="product-card">
                  {/* <img src={item.images} alt={item.name} width="60" /> */}
                  <img src={item.images[0]} alt={item.name} />
                  <span>{item.name} - €{item.price.toFixed(2)}</span>
                  {/* <ProductCard key={item.id} name={item.name} price={item.price} images={item.images} /> */}
                  <button className = "cardButton" onClick={() => removeFromBasket(item.id)}>Remove</button>
                  </div>
                </li>
              ))}
            </ul>
            {/* Display the total price with two decimal places */}
            <h3 className="total" >Total: €{total.toFixed(2)}</h3>

            {/* Link to checkout */}
            <Link to="/Checkout" className="nav-btn">* Checkout *</Link>
        </>
      )}
    </section>
  );
}
