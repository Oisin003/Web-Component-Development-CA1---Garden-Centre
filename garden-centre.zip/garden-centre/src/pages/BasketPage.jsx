// src/pages/BasketPage.jsx
import { useContext } from "react";
import { Link } from "react-router-dom";
import { BasketContext } from "../context/BasketContext";

export default function BasketPage() {
  let { basketItems, removeFromBasket } = useContext(BasketContext);

  // Calculate total price dynamically
  let total = basketItems.reduce((sum, item) => sum + item.price, 0);

  return (
    <section className="basket-page">
      <h2>Basket</h2>

      {basketItems.length === 0 ? (
        <p>Basket is empty.</p>
      ) : (
        <>
          <ul>
            {basketItems.map((item) => ( // Map over each item in the basket and display its details
              <li key={item.id}> {/* Unique key for each item */}
                <img src={item.image} alt={item.name} width="60" />
                <span>{item.name} - €{item.price.toFixed(2)}</span>
                <button onClick={() => removeFromBasket(item.id)}>Remove</button>
              </li>
            ))}
          </ul>
          {/* Display the total price with two decimal places */}
          <h3>Total: €{total.toFixed(2)}</h3>

          {/* Link to checkout */}
          <Link to="/checkout" className="nav-btn">* Checkout *</Link>
        </>
      )}
    </section>
  );
}
