// src/pages/Home.jsx
import { Link } from "react-router-dom";

export default function Home() {
  return (
    <section className="home">
      <h2>Welcome to the Garden Centre</h2>
      <p>Select a category to start shopping:</p>
      <div className="category-links">
        <Link to="/plants" className="nav-btn">🌱 Plants</Link>
        <Link to="/tools" className="nav-btn">🛠 Tools</Link>
        <Link to="/garden-care" className="nav-btn">🧴 Garden Care</Link>
      </div>
    </section>
  );
}
