// src/pages/ProductsPage.jsx
import { useEffect, useState } from "react";
import ProductCard from "../components/ProductCard";
import { products } from "../data/stock";

export default function ProductsPage({ category }) { // ProductsPage component that takes a category prop
  // Initialize state items with empty array then provide a function to update the state
  let [items, setItems] = useState([]);// State to hold products of the selected category

  useEffect(() => { // React hook to perform side effects
    // Load the category's products dynamically
    setItems(products[category] || []);
  }, [category]);

  return (
    <section>
      <h2 className= "pageHeaders">{category}</h2>
      <div className="product-grid">
        {items.map((p) => (
          <ProductCard key={p.id} name={p.name} price={p.price} images={p.images} />
        ))}
      </div>
    </section>
  );
}
