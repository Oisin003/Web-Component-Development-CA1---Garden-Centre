// src/data/products.js
export const products = {
  Plants: [
    { id: 1, name: "Rose Bush", price: 9.99, image: "/images/rose.jpg" },
    { id: 2, name: "Lavender", price: 7.5, image: "/images/lavender.jpg" },
  ],
  Tools: [
    { id: 3, name: "Garden Shovel", price: 15.0, image: "/images/shovel.jpg" },
    { id: 4, name: "Pruning Shears", price: 12.99, image: "/images/shears.jpg" },
  ],
  "Garden Care": [
    { id: 5, name: "Fertilizer", price: 11.99, image: "/images/fertilizer.jpg" },
    { id: 6, name: "Compost", price: 8.5, image: "/images/compost.jpg" },
  ],
};
