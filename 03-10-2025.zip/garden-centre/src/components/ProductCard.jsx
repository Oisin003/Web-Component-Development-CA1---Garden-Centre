// Oisin Gibson
// L00172671
// src/components/ProductCard.jsx

// Import React hooks
import React, { useContext, useState } from "react";

// Import the basket context to access shared basket functions and data
import { useBasket } from "../context/BasketContext";

// Import styles specific to the product card
import "../ProductCard.css";

// Define the ProductCard component + receive product details as props
export default function ProductCard({ item, id, name, price, images, placeholderMessage }) {
  // If the item exists use it (? = if else), else check if ide exists, null means no product
  const product = item || (id ? { id, name, price, images } : null);

  // Access basket-related functions and data from context
  const { addToBasket, removeFromBasket, basketItems } = useBasket();

  // initialize "added" from basket state if product exists
  const [added, setAdded] = useState(() =>// arrow function to initialize added state
    Boolean(product && basketItems?.some((b) => b.id === product.id))
  );

  // If there's no product data, render a placeholder card
  if (!product) {
    return (
      <div className="product-card placeholder">
        <div className="product-image placeholder-image" />
        <div className="product-info">
          <h3>{placeholderMessage || "Item not found"}</h3>
        </div>
      </div>
    );
  }
  //Set image source, check images array first, then single image, else empty string
  const imgSrc = product.images?.[0] || product.image || "";

  const basketItem = basketItems?.find((b) => b.id === product.id);
  const quantity = basketItem?.quantity || 0;

  const handleAdd = () => {
    addToBasket(product);
  };

  const handleRemove = () => {
    removeFromBasket(product);
  };

  // Render the product card UI
  return (
    <div className="product-card">
      {imgSrc ? (// If imgSrc exists, render the image
        <img
          src={imgSrc}
          alt={product.name}
          onError={(e) => {// Arrow function to handle image load errors
            console.warn("Image failed to load:", imgSrc);// Log a warning with the failed src
            e.currentTarget.onerror = null;// Prevent infinite loop if placeholder also fails - part of onError handling
            e.currentTarget.src = "/images/placeholder.png";
          }}
        />
      ) : (// Else render a placeholder div
        <div className="product-image placeholder-image" />
      )}

      <div className="content">
        <h3>{product.name}</h3>
        <div className="meta">
          {/* // Default to 0 if price is undefined, format to 2 decimal places */}
          <p>€{(product.price ?? 0).toFixed(2)}</p>
        </div>
        <div>
          <button className="cardButton" onClick={handleAdd}>
            Add
          </button>
          {quantity > 0 && (
            <>
              <span style={{ margin: "0 8px" }}>Quantity: {quantity}</span>
              <button className="cardButton" onClick={handleRemove}>
                Remove
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
