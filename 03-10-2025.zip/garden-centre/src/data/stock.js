// src/data/stock.js

export const products = {
  Plants: [
    { id: 1, name: "Rose", price: 10.0, images: ["/images/plants/Rose1.webp", "/images/plants/Rose2.jpg"] },
    { id: 2, name: "Tulip", price: 5.0, images: ["/images/plants/Tulip1.webp", "/images/plants/Tulip2.webp"] },
    { id: 3, name: "Daffodil", price: 7.0, images: ["/images/plants/Daffodil1.webp", "/images/plants/Daffodil2.webp"] },
    { id: 4, name: "Sunflower", price: 8.0, images: ["/images/plants/Sunflower1.jpg", "/images/plants/sunflower2.jpg"] },
    { id: 5, name: "Orchid", price: 20.0, images: ["/images/plants/orchid1.jpg", "/images/plants/orchid2.jpg"] },
    { id: 6, name: "Lily", price: 6.5, images: ["/images/plants/lily1.jpg", "/images/plants/lily2.jpg"] },
    { id: 7, name: "Daisy", price: 9.0, images: ["/images/plants/daisy1.jpg", "/images/plants/daisy2.jpg"] },
    { id: 8, name: "Hyacinth", price: 11.0, images: ["/images/plants/hyacinth1.jpg", "/images/plants/hyacinth2.jpg"] },
    { id: 9, name: "Begonia", price: 4.5, images: ["/images/plants/begonia1.jpg", "/images/plants/begonia2.jpg"] },
    { id: 10, name: "Marigold", price: 3.99, images: ["/images/plants/marigold1.jpg", "/images/plants/marigold2.jpg"] },
    { id: 11, name: "Petunia", price: 4.25, images: ["/images/plants/petunia1.jpg", "/images/plants/petunia2.jpg"] },
    { id: 12, name: "Chrysanthemum", price: 6.75, images: ["/images/plants/chrysanthemum1.jpg", "/images/plants/chrysanthemum2.jpg"] },
    { id: 37, name: "Lavender", price: 9.80, images: ["/images/plants/lavender1.webp", "/images/plants/lavender2.webp"] }
  ],

  Tools: [
    { id: 13, name: "Shovel", price: 25.0, images: ["/images/tools/shovel1.jpg", "/images/tools/shovel2.jpg"] },
    { id: 14, name: "Pruning Shears", price: 12.49, images: ["/images/tools/shears1.jpg", "/images/tools/shears2.jpg"] },
    { id: 15, name: "Rake", price: 15.0, images: ["/images/tools/rake1.png", "/images/tools/rake2.jpg"] },
    { id: 16, name: "Hoe", price: 13.5, images: ["/images/tools/hoe1.jpg", "/images/tools/hoe2.jpg"] },
    { id: 17, name: "Trowel", price: 6.99, images: ["/images/tools/trowel1.jpg", "/images/tools/trowel2.jpg"] },
    { id: 18, name: "Wheelbarrow", price: 49.99, images: ["/images/tools/wheelbarrow1.jpg", "/images/tools/wheelbarrow2.jpg"] },
    { id: 19, name: "Garden Fork", price: 18.0, images: ["/images/tools/fork1.jpg", "/images/tools/fork2.jpg"] },
    { id: 20, name: "Gloves", price: 5.5, images: ["/images/tools/gloves1.jpg", "/images/tools/gloves2.jpg"] },
    { id: 21, name: "Watering Can", price: 9.99, images: ["/images/tools/wateringcan1.jpg", "/images/tools/wateringcan2.jpg"] },
    { id: 22, name: "Loppers", price: 22.0, images: ["/images/tools/loppers1.jpg", "/images/tools/loppers2.png"] },
    { id: 23, name: "Garden Knife", price: 7.5, images: ["/images/tools/knife1.jpg", "/images/tools/knife2.jpg"] },
    { id: 24, name: "Sprayer", price: 14.99, images: ["/images/tools/sprayer1.jpg", "/images/tools/sprayer2.jpg"] }
  ],

  "Garden Care": [
    { id: 25, name: "Tree Ties", price: 1.29, images: ["/images/care/ties1.jpg", "/images/care/ties2.jpg"] },
    { id: 26, name: "Fertilizer", price: 8.99, images: ["/images/care/fertilizer1.jpg", "/images/care/fertilizer2.jpg"] },
    { id: 27, name: "Compost", price: 6.5, images: ["/images/care/compost1.jpg", "/images/care/compost2.jpg"] },
    { id: 28, name: "Mulch", price: 4.75, images: ["/images/care/mulch1.jpg", "/images/care/mulch2.jpg"] },
    { id: 29, name: "Plant Food", price: 7.25, images: ["/images/care/plantfood1.jpg", "/images/care/plantfood2.jpg"] },
    { id: 30, name: "Weed Killer", price: 11.0, images: ["/images/care/weedkiller1.jpg", "/images/care/weedkiller2.jpg"] },
    { id: 31, name: "Pest Spray", price: 9.5, images: ["/images/care/pestspray1.webp", "/images/care/pestspray2.jpg"] },
    { id: 32, name: "Soil Conditioner", price: 5.99, images: ["/images/care/soil1.jpg", "/images/care/soil2.jpg"] },
    { id: 33, name: "Lawn Feed", price: 10.0, images: ["/images/care/lawnfeed1.jpg", "/images/care/lawnfeed2.jpg"] },
    { id: 34, name: "Slug Pellets", price: 3.99, images: ["/images/care/slug1.jpg", "/images/care/slug2.jpg"] },
    { id: 35, name: "Root Booster", price: 6.25, images: ["/images/care/rootbooster1.png", "/images/care/rootbooster2.jpg"] },
    { id: 36, name: "Plant Stakes", price: 2.5, images: ["/images/care/stakes1.jpg", "/images/care/stakes2.jpg"] }
  ]
};
